document.getElementById("jsdemo").innerHTML = "이 내용은 javascript로 작성되었습니다."
document.getElementById("jsimage").src = "3mb.png"